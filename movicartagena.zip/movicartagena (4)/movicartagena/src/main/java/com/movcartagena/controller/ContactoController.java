package com.movcartagena.controller;

import com.movcartagena.model.Contacto;
import com.movcartagena.repository.ContactoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class ContactoController {

    @Autowired
    private ContactoRepository contactoRepository;

    @PostMapping("/contacto")
    public String enviarContacto(@RequestParam String nombre, @RequestParam String correo, 
                                 @RequestParam String telefono, @RequestParam String mensaje) {
        Contacto contacto = new Contacto();
        contacto.setNombre(nombre);
        contacto.setCorreo(correo);
        contacto.setTelefono(telefono);
        contacto.setMensaje(mensaje);
        contactoRepository.save(contacto);
        return "contacto_exitoso";  // Debes crear una vista para esto
    }
}
