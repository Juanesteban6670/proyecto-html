package com.movcartagena.controller;

import com.movcartagena.model.Registro;
import com.movcartagena.repository.RegistroRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class RegistroController {

    @Autowired
    private RegistroRepository registroRepository;

    @PostMapping("/registro")
    public String registrarUsuario(@RequestParam String nombre, @RequestParam String email, 
                                   @RequestParam String contrasena) {
        Registro registro = new Registro();
        registro.setNombre(nombre);
        registro.setEmail(email);
        registro.setContrasena(contrasena);
        registroRepository.save(registro);
        return "registro_exitoso";  // Debes crear una vista para esto
    }
}
